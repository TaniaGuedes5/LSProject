import React from "react";

import "./BigBoard.css";
import { Board } from "./Board";

export const BigBoard = ({
  boards,
  lockedBoards,
  smallBoardWinners,
  onCellClick,
  selectedMiniBoard,
}) => {
  return (
    <div className="big-board">
      {boards.map((board, boardIndex) => (
        <div
          key={boardIndex}
          className="mini-board"
          style={{ backgroundColor: selectedMiniBoard === boardIndex ? '#ffe58f' : 'white', 
          transition: 'background-color 0.2s ease-in-out'}}
        >
          <Board
            board={board}
            isLocked={lockedBoards[boardIndex]}
            onClick={(cellIndex) => onCellClick(boardIndex, cellIndex)}
          />
          {lockedBoards[boardIndex] && (
            <div className="lock-overlay">
              {smallBoardWinners[boardIndex] === "X" ? (
                <div className="cross"></div>
              ) : smallBoardWinners[boardIndex] === "O" ? (
                <div className="circle"></div>
              ) : smallBoardWinners[boardIndex] === "D" ? (
                <div className="draw-dash"></div>
              ) : null}
            </div>
          )}
        </div>
      ))}
    </div>
  );
};
