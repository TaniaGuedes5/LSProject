import React from 'react';
import "./GameMenu.css";
import gameImage from './gameImage.png'; // Import the image file

const GameMenu = ({ onSelectGameMode }) => {
  const handleSelectGame = (gameMode) => {
    onSelectGameMode(gameMode);
  };

  return (
    <div className="gameMenuContainer">
      <h2 className='titleGameMode'>Game Mode</h2>
      <button className='button' onClick={() => handleSelectGame('twoPlayers')}>Player vs Player</button>
      <button className='button' onClick={() => handleSelectGame('onePlayer')}>Player vs Computer</button>
      <img className='image' src={gameImage} alt="Game" />
    </div>
  );
};

export default GameMenu;